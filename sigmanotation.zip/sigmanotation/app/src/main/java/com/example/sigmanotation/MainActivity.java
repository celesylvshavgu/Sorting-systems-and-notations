package com.example.sigmanotation;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText inputArray = findViewById(R.id.input_array);
        Button sortButton = findViewById(R.id.sort_button);
        TextView sortedArrayText = findViewById(R.id.sorted_array_text);

        sortButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = inputArray.getText().toString();
                int[] array = parseInputToArray(input);
                sortedArrayText.setText(arrayToString(sigma_notation(array)));
            }
        });
    }

    private int[] parseInputToArray(String input) {
        String[] stringArray = input.split(",");
        int[] intArray = new int[stringArray.length];
        for (int i = 0; i < stringArray.length; i++) {
            intArray[i] = Integer.parseInt(stringArray[i].trim());
        }
        return intArray;
    }

    public int sigma_notation(int[] args) {
        int sum = 0;

        // Loop through values of k from 1 to 6 and calculate the sum of (2k + 1)
        for (int k = args[0]; k <= args[1]; k++) {
            sum += (2 * k + 1);
        }

        return sum;
    }

    private String arrayToString(int array) {
        StringBuilder sb = new StringBuilder();
        sb.append(array).append(" ");

        return sb.toString().trim();
    }
}